import { useNavigate } from "react-router-dom";
import "../App.css";
import { useState, useEffect } from "react";

export const LoginPage = (props) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState("");

  const login = async () => {
    try {
      let login = "";
      username.includes("@") ? (login += "email") : (login += "username");
      let response = await fetch("https://localhost:7271/Login", {
        method: "POST",

        headers: {
          accept: "application/json",
          "Content-Type": "application/json; charset=utf-8",
        },
        body: JSON.stringify({
          firstName: "",
          lastName: "",
          username: "",
          email: username,
          passphrase: password,
          token: "",
          age: 0,
          gender: "",
          paid: false,
          isAdmin: false,
        }),
      });

      let user = await response.json();
      if (user.token === "Login Successful") {
        props.user({
          age: user.age,
          email: user.email,
          firstname: user.firstName,
          lastname: user.lastName,
          username: user.username,
          password: user.password,
          gender: user.gender,
          paid: user.paid,
          isAdmin: user.Admin,
        });
        console.log(props);
        loggedIn();
      } else {
        setStatus("Username or Password Incorrect");
      }
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    if (
      props.userData.username !== undefined &&
      props.userData.username !== ""
    ) {
      loggedIn();
    }
  }, []);

  let navigate = useNavigate();

  const loggedIn = () => {
    let path = "";
    if (props.user.isAdmin) {
      path = "/admin";
    } else {
      path = "/home";
    }
    navigate(path);
  };

  const routeChange = () => {
    let path = "/register";
    navigate(path);
  };
  return (
    <div className="App">
      <header className="App-header">
        <div className="loginBox">
          <h7 className="boxheader" style={{ color: "#46475d", fontSize: 48 }}>
            Sign in
          </h7>
          <br />
          <input
            className="loginInput"
            placeholder="username"
            onChange={(e) => setUsername(e.target.value)}
          />
          <br />
          <input
            className="loginInput"
            placeholder="password"
            type="password"
            onChange={(e) => setPassword(e.target.value)}
          />
          <br />
          <div style={{ marginTop: 40 }}>
            <button className="bigbutton" onClick={routeChange}>
              Create Account
            </button>
            <button
              className="bigbutton"
              onClick={login}
              style={{ marginLeft: 100 }}
            >
              Login
            </button>
          </div>
          <p>{status}</p>
        </div>
      </header>
    </div>
  );
};
