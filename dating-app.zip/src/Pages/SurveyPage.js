import { useNavigate } from "react-router-dom";
import "../App.css";
import { useState, useEffect } from "react";

function SurveyPage(props) {

    return (
        <div className="App">
            <header className="App-header">
                <div className="adminBox">
                    <h7>Their Email: {props.email}</h7>
                    <h7>Survey</h7>
                    <h7>On a scale of one to five with one being the worst and five being the best how was the match</h7>
                    <div style={{ flexDirection: 'row', padding: 20 }}>
                        <button
                            className="skill-button"
                            type="contained"
                            onClick={() => props.survey(1)}
                        >
                            one
                        </button>
                        <button
                            className="skill-button"
                            type="contained"
                            onClick={() => props.survey(2)}
                        >
                            two
                        </button>
                        <button
                            className="skill-button"
                            type="contained"
                            onClick={() => props.survey(3)}
                        >
                            three
                        </button>
                        <button
                            className="skill-button"
                            type="contained"
                            onClick={() => props.survey(4)}
                        >
                            four
                        </button>
                        <button
                            className="skill-button"
                            type="contained"
                            onClick={() => props.survey(5)}
                        >
                            five
                        </button>
                    </div>
                </div>
            </header >
        </div >
    );
}

export default SurveyPage;
