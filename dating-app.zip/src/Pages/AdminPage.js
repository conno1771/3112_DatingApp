import { useNavigate } from "react-router-dom";
import "../App.css";
import { useState, useEffect } from "react";

const testUsers = {
  men: 3,
  women: 4,
  other: 3,
  userCount: 10,
  paidUserCount: 6,
  adminCount: 1,
  teen: 1,
  twenty: 1,
  thirty: 1,
  fourty: 1,
  fifty: 1,
  sixty: 1,
  seventy: 1,
  eighty: 1,
  surveyone: 3,
  surveytwo: 3,
  surveythree: 3,
  surveyfour: 3,
  surveyfive: 3,
};

function AdminPage(props) {
  const [username, setUsername] = useState("");
  const [stats, setStats] = useState({});

  useEffect(() => {
    if (props.userData.username === undefined) {
      notLoggedIn();
    } else {
      setUsername(props.userData.username);
    }
    setStats(testUsers);
  }, []);

  let navigate = useNavigate();

  const notLoggedIn = () => {
    let path = "/";
    //navigate(path);
  };

  return (
    <div className="App">
      <header className="App-header">
        <div className="adminBox">
          <h7>ADMIN DASHBOARD</h7>
          <h7>Number of users: {stats.userCount}</h7>
          <div style={{ flexDirection: "row", padding: 20 }}>
            <ul
              style={{
                float: "left",
                height: "auto",
                listStyle: "none",
                lineHeight: 1.5,
                backgroundColor: "#46475d",
                padding: 10,
                borderRadius: 20,
                color: "white",
              }}
            >
              <li style={{ fontWeight: 600 }}>Monetization Statistics</li>
              <li>Number of paid users: {stats.paidUserCount}</li>
              <li>
                Number of free users: {stats.userCount - stats.paidUserCount}
              </li>
              <li>Number of admins: {stats.adminCount}</li>
            </ul>
            <ul
              style={{
                marginLeft: "11%",
                float: "left",
                height: "auto",
                listStyle: "none",
                lineHeight: 1.5,
                backgroundColor: "#46475d",
                padding: 10,
                borderRadius: 20,
                color: "white",
              }}
            >
              <li style={{ fontWeight: 600 }}>Gender Statistics</li>
              <li>Number of Men: {stats.men}</li>
              <li>Number of Women: {stats.women}</li>
              <li>Number of Other: {stats.other}</li>
            </ul>
            <ul
              style={{
                marginLeft: "11%",
                float: "left",
                height: "auto",
                listStyle: "none",
                lineHeight: 1.5,
                backgroundColor: "#46475d",
                padding: 10,
                borderRadius: 20,
                color: "white",
              }}
            >
              <li style={{ fontWeight: 600 }}>Age Statistics</li>
              <li>18-19: {stats.teen}</li>
              <li>20-29: {stats.twenty}</li>
              <li>30-39: {stats.thirty}</li>
              <li>40-49: {stats.fourty}</li>
              <li>50-59: {stats.fifty}</li>
              <li>60-69: {stats.sixty}</li>
              <li>70-79: {stats.seventy}</li>
              <li>80+: {stats.eighty}</li>
            </ul>
            <ul
              style={{
                marginLeft: "11%",
                float: "left",
                height: "auto",
                listStyle: "none",
                lineHeight: 1.5,
                backgroundColor: "#46475d",
                padding: 10,
                borderRadius: 20,
                color: "white",
              }}
            >
              <li style={{ fontWeight: 600 }}>Survey Results</li>
              <li>1: {stats.surveyone}</li>
              <li>2: {stats.surveytwo}</li>
              <li>3: {stats.surveythree}</li>
              <li>4: {stats.surveyfour}</li>
              <li>5: {stats.surveyfive}</li>
            </ul>
          </div>
        </div>
      </header>
    </div>
  );
}

export default AdminPage;
