import { useNavigate } from "react-router-dom";
import "../App.css";
import { useState, useEffect } from "react";
function HomePage(props) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [email, setEmail] = useState("");
  const [isPaid, setIsPaid] = useState(false);
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [userSkills, setUserSkills] = useState([]);

  useEffect(() => {
    if (props.userData.username === undefined) {
      notLoggedIn();
    } else {
      setUsername(props.userData.username);
      setPassword(props.userData.password);
      setAge(props.userData.age);
      setFirstname(props.userData.firstname);
      setLastname(props.userData.lastname);
      setEmail(props.userData.email);
      setGender(props.userData.gender);
      setIsPaid(props.userData.paid);

      fetch(
        `https://localhost:7271/GetUserSkills?email=${props.userData.email}`
      )
        .then((res) => {
          if (res !== undefined) {
            res
              .json()
              .then((body) => setUserSkills(body))
              .catch((err) => console.log(err));
          }
        })
        .catch((err) => console.log(err));
    }
  }, []);

  let navigate = useNavigate();

  const notLoggedIn = () => {
    let path = "/";
    navigate(path);
  };

  return (
    <div className="App">
      <header className="App-header">
        <div className="homeBox">
          <div className="user-info">
            <p>
              Name: {firstname} {lastname}
            </p>
            <p>Email: {email}</p>
            <br/>
            <h4>Your Skills</h4>
            <div className="user-skills-list">{userSkills.map((skill) => (
              <p className="user-skill-list-item">{skill}</p>
            ))}</div>
          </div>
          <div className="paid-user-content">
            {isPaid === true ? (
              <p>Paid Content Coming Soon</p>
            ) : (
              <p>Unlock Content by Paying</p>
            )}
          </div>
          <div className="Submit-Skills-Button-Div">
            <button
              variant="contained"
              className="Submit-Skills-Button"
              onClick={() => {
                navigate("/skillspage", { params: { email: email } });
              }}
            >
              Add Skills
            </button>
            <button
              variant="contained"
              className="Submit-Skills-Button"
              onClick={() => {
                navigate("/");
                props.user({
                    age: 0,
                    email: "",
                    firstname: "",
                    lastname: "",
                    username: "",
                    password: "",
                    gender: "",
                    paid: false,
                    isAdmin: false,
                  });
              }}
            >
              Sign Out
            </button>
          </div>
        </div>
      </header>
    </div>
  );
}

export default HomePage;
