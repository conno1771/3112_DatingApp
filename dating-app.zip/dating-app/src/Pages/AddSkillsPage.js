import { useNavigate } from "react-router-dom";
import "../App.css";
import { useState, useEffect, useRef } from "react";

function SkillsPage(props) {
  const [availableSkills, setAvailableSkills] = useState([]);
  const [userSkills, setUserSkills] = useState([]);
  const [status, setStatus] = useState("");
  const effRan = useRef();
  const navigate = useNavigate();
  useEffect(() => {
    if (props.userData.length === 0) {
      navigate("/");
    } else {
      fetchFreshData();
    }
  }, []);
  const fetchFreshData = () => {
    if (!effRan.current) {
      fetch("https://localhost:7271/GetAllSkills")
        .then((res) => {
          res
            .json()
            .then((body) => {
              var tempBody = [];
              body.forEach((element) => {
                tempBody.push({ skill: element.skill, checked: false });
              });
              setAvailableSkills(tempBody);
            })
            .catch((err) => console.log(err));
        })
        .catch((err) => console.log(err));

      fetch(
        `https://localhost:7271/GetUserSkills?email=${props.userData.email}`
      )
        .then((res) => {
          if (res !== undefined) {
            res
              .json()
              .then((body) => setUserSkills(body))
              .catch((err) => console.log(err));
          }
        })
        .catch((err) => console.log(err));
    }
    effRan.current = true;
  };
  const selectedSkill = (skill) => {
    if (userSkills.includes(skill.skill)) {
      //remove skill from users skill list
      var tempSkills = [];
      userSkills.forEach((_skill) => {
        if (_skill != skill.skill) {
          tempSkills.push(_skill);
        }
      });

      console.log("skill removed: " + skill.skill);

      setUserSkills(tempSkills);
    } else {
      console.log("skill added: " + skill.skill);
      setUserSkills([...userSkills, skill.skill]);
    }
  };
  const updateSkillsDb = () => {
    fetch(
      `https://localhost:7271/UpdateUserSkills?email=${props.userData.email}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify([...userSkills]),
      }
    )
      .then((res) => {
        res
          .json()
          .then((body) => {
            if (body.token === "Skills Added") {
              setStatus("Skills Updated");
              console.log("Skills Updated");
              fetchFreshData();
            } else {
              setStatus("ERROR: did not save skills");
              console.log("ERROR: did not save skills");
            }
          })
          .catch((err) => console.log(err));
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <div className="App">
      <header className="App-header">
        <div className="skillsBox">
          <div className="skillsbox-header">
            <button className="backbutton" onClick={()=>navigate("/home")}>Back</button>
            <h1>Skills</h1>
          </div>
          <div className="skills-content">
            <h6>Your Skills: {userSkills.map((skill) => skill + ", ")}</h6>
            <h6>{status}</h6>
            {availableSkills.length > 0 ? (
              <div className="Skills-List">
                {availableSkills.map((skill) => (
                  <div className="Skills-List-Item" key={skill.skill}>
                    <button
                      className="skill-button"
                      type="contained"
                      onClick={() => selectedSkill(skill)}
                    >
                      {skill.skill}
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <h3>No Skills Loaded</h3>
            )}
          </div>
        </div>

        <button
          disabled={availableSkills.length < 1}
          className="Submit-Skills-Button"
          type="contained"
          onClick={updateSkillsDb}
        >
          SUBMIT
        </button>
      </header>
    </div>
  );
}
export default SkillsPage;
