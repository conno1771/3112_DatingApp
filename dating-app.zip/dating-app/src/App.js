import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { useState } from 'react'
import { LoginPage } from './Pages/LoginPage';
import RegisterPage from './Pages/RegisterPage';
import HomePage from './Pages/HomePage';
import SkillsPage from './Pages/AddSkillsPage';

const App = () => {
  const [toChild, setToChild] = useState([]);

  const getUserFromChild = (childProps) => {
    setToChild({
      age: childProps.age,
      email: childProps.email,
      firstname: childProps.firstname,
      lastname: childProps.lastname,
      username: childProps.username,
      password: childProps.password,
      gender: childProps.gender,
      paid: childProps.paid,
      isAdmin: childProps.isAdmin
    })
  }
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<LoginPage user={getUserFromChild} userData={toChild} />} />
        <Route path='/register' element={<RegisterPage user={getUserFromChild} />} />
        <Route path='/home' element={<HomePage user={getUserFromChild} userData={toChild} />} />
        <Route path='/skillspage' element={<SkillsPage userData={toChild}/>}/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
