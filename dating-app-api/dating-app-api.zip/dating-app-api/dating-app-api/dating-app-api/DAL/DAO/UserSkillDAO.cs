﻿using dating_app_api.DAL.DomainClasses;
using System.Runtime.InteropServices;

namespace dating_app_api.DAL.DAO
{
    public class UserSkillDAO
    {
        private readonly AppDbContext _db;
        public UserSkillDAO(AppDbContext db)
        {
            _db = db;
        }
        public async Task<List<UserSkill>> AddUserSkills(int uid, string[] skills)
        {
            List<UserSkill> list = new List<UserSkill>();
            List<Skills> allSkills = new List<Skills>();
            var userskills = _db.UserSkills!.Where(u => u.UserID == uid).ToList();
            allSkills = _db.Skills!.Where(s => s != null).ToList();
            foreach (var skill in skills)
            {
                UserSkill? userSkill = new UserSkill(uid, skill);
                //using try catch because skill must be one of those in the skill table
                //should only throw exception during testing
                try
                {
                    List<string> userSkillsStr = new List<string>();
                    foreach (var item in userskills)
                    {
                        userSkillsStr.Add(item.Skill);
                    }
                    if (!userSkillsStr.Contains(skill))
                    {
                        await _db.UserSkills!.AddAsync(userSkill);
                        await _db.SaveChangesAsync();

                    }
                    list.Add(userSkill);
                }
                catch (Exception)
                {
                    throw;
                }
            }

            foreach (var skill in userskills)
            {
                if (!skills.Contains(skill.Skill))
                {
                    _db.UserSkills!.Remove(skill);

                    await _db.SaveChangesAsync();
                    list.Remove(skill);
                }
            }

            return list;
        }
        public async Task<UserSkill> GetUserSkill(int uid, string skill)
        {
            UserSkill? userSkill = await _db.UserSkills!.FindAsync(uid, skill);
            return userSkill;
        }
        public async Task<List<UserSkill>> GetUserSkills(int uid)
        {
            List<UserSkill?>? userSkills = _db.UserSkills!.Where(u => u.UserID == uid).ToList()!;
            if (userSkills.Count == 0)
            {
                return new List<UserSkill>();
            }
            return userSkills!;
        }
        public async Task<List<Skills>> GetAllSkills()
        {
            List<Skills> skills = _db.Skills!.ToList()!;
            return skills;
        }
    }
}
