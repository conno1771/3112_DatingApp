﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace dating_app_api.DAL.DomainClasses
{
    public class Skills
    {
        [Key]
        public string Skill { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
    }
}
