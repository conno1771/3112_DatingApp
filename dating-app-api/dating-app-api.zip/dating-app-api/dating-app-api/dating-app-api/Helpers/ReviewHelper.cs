﻿namespace dating_app_api.Helpers
{
    public class ReviewHelper
    {
        public int? Id { get; set; } = 0;
        public int? Quality { get; set; } = 0;
        public int? UserId { get; set; } = 0;
        public string? ReviewDate { get; set; } = null;
        public string? Token { get; set; } = "";
    }
}