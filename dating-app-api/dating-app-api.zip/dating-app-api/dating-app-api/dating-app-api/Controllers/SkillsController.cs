﻿using dating_app_api.DAL;
using dating_app_api.DAL.DAO;
using dating_app_api.DAL.DomainClasses;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace dating_app_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SkillsController : ControllerBase
    {
        readonly AppDbContext? _ctx;
        public SkillsController(AppDbContext? ctx)
        {
            _ctx = ctx;
        }

        [HttpGet]
        [Route("/GetAllSkills")]
        [AllowAnonymous]
        [Produces("application/json")]
        public async Task<List<Skills>> GetAllSkills()
        {
            UserSkillDAO usDAO = new(_ctx);
            List<Skills> skills = await usDAO.GetAllSkills();
            return skills;
        }
    }
}
